// Ourselves:
#include <jsontools/i_jsonizable.h>

namespace jsontools {

  i_jsonizable::i_jsonizable()
  {
    return;
  }

  i_jsonizable::~i_jsonizable()
  {
    return;
  }

} // end of namespace jsontools
