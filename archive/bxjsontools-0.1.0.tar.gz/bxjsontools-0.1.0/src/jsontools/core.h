// -*- mode: c++; -*-

#ifndef BXJSONTOOLS_CORE_H
#define BXJSONTOOLS_CORE_H

namespace jsontools {

  template<typename ...T>
  class converter;

  template<typename ...T>
  class converter_split;

} // end of namespace jsontools

#endif // BXJSONTOOLS_CORE_H
