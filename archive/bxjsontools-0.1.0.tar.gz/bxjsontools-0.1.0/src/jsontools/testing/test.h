// -*- mode: c++; -*-

#ifndef BXJSONTOOLS_TESTING_TEST_H
#define BXJSONTOOLS_TESTING_TEST_H

namespace jsontools {

  namespace testing {

    class test
    {
    public:

      static void run_test_0();

      static void run_test_1();

      static void run_test_2();

      static void run_test_3();

      static void run_test_4();

    };

  } // end of namespace testing

} // end of namespace jsontools

#endif // BXJSONTOOLS_TESTING_TEST_H
